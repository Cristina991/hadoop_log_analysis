package cn.wust.com.demo.pojo;

import lombok.Data;

@Data
public class selltopcatPojo {
    int catid;
    int buyamount;
}
