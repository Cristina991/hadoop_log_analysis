package cn.wust.com.demo.pojo;

import lombok.Data;

@Data
public class IpEveryhour {
    int dstcipcnts;
    String hour;
}
