package cn.wust.com.demo.pojo;

import lombok.Data;

@Data
public class selltopitemPojo {
    int itemid;
    int buyamount;
}
