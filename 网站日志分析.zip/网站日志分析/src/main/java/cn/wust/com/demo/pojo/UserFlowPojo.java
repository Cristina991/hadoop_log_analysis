package cn.wust.com.demo.pojo;

import lombok.Data;

@Data
public class UserFlowPojo {
    String date;
    int visitors;
    int views;
    double avgviews;

}
