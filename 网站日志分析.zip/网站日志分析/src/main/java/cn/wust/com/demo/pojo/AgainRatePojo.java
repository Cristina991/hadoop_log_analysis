package cn.wust.com.demo.pojo;

import lombok.Data;

@Data
public class AgainRatePojo {
    int again;
    int buynum;
    double againrate;
}
