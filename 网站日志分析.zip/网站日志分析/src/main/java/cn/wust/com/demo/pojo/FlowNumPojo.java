package cn.wust.com.demo.pojo;

public class FlowNumPojo {
//    List<String> dates;? = null
//    var new_uvs: List<String>? = null


}
