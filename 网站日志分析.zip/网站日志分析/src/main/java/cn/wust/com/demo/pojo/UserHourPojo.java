package cn.wust.com.demo.pojo;

import lombok.Data;

@Data
public class UserHourPojo {
    int hour;
    int  pvhour;
    int carthour;
    int favhour;
    int buyhour;
}
