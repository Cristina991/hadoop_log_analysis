package cn.wust.com.demo.pojo;

import lombok.Data;

@Data
public class HotPageTop10 {
    String url;
    int pvs;
}
