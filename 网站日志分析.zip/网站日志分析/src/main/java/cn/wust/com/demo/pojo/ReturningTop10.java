package cn.wust.com.demo.pojo;

import lombok.Data;

@Data
public class ReturningTop10 {
    String remoteaddr ;
    int acccnt;

}
