package cn.wust.com.demo.pojo;

import lombok.Data;

@Data
public class PvsEveryhour {
    int month;
    int day;
    int hour;
    int pvs;

}
