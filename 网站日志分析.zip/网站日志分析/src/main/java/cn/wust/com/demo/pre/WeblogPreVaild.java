package cn.wust.com.demo.pre;

public class WeblogPreVaild {
}
